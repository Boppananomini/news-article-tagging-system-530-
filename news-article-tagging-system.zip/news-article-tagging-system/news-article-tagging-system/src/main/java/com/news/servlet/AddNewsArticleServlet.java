package com.news.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.news.dao.NewsArticleDAO;
import com.news.model.NewsArticle;

@WebServlet("/addArticleServlet")
public class AddNewsArticleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String content = request.getParameter("content");

        NewsArticle article = new NewsArticle();
        article.setTitle(title);
        article.setContent(content);

        new NewsArticleDAO().saveArticle(article);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1 style='text-align:center;'>Article Added Successfully</h1>");
        out.println("<h2 style='text-align:center;'><a href='listArticlesServlet'>View Articles</a></h2>");
    }
}
