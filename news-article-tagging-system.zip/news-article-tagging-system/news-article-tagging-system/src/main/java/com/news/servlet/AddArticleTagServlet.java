package com.news.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.news.dao.HibernateUtil;
import com.news.model.ArticleTag;

@WebServlet("/addTagServlet")
public class AddArticleTagServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String tagName = request.getParameter("tagName");

        ArticleTag tag = new ArticleTag();
        tag.setTagName(tagName);

        Session session = HibernateUtil.getFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.persist(tag);
        tx.commit();
        session.close();

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1 style='text-align:center;'>Tag Added Successfully</h1>");
        out.println("<h2 style='text-align:center;'><a href='list_article_tags.jsp'>View Tags</a></h2>");
    }
}
