package com.news.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.news.model.ArticleTag;
import util.HibernateUtil;

@WebServlet("/updateTagServlet")
public class UpdateArticleTagServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int tagId = Integer.parseInt(request.getParameter("id"));
        String tagName = request.getParameter("tagName");

        Session hibSession = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = hibSession.beginTransaction();

        ArticleTag tag = hibSession.get(ArticleTag.class, tagId);
        if (tag != null) {
            tag.setTagName(tagName);
            hibSession.merge(tag);
        }

        tx.commit();
        hibSession.close();

        response.sendRedirect("listTags.jsp");
    }
}
