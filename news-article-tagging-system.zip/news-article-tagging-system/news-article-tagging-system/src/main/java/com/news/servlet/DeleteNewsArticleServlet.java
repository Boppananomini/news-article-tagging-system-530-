package com.news.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.news.dao.HibernateUtil;
import com.news.model.NewsArticle;

@WebServlet("/DeleteNewsArticleServlet")
public class DeleteNewsArticleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));

            Session session = HibernateUtil.getFactory().openSession();
            Transaction tx = session.beginTransaction();

            NewsArticle article = session.get(NewsArticle.class, id);
            if (article != null) {
                session.delete(article);
            }

            tx.commit();
            session.close();

            // ✅ Redirect back to list page
            response.sendRedirect("ListArticlesServlet");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ListArticlesServlet");
        }
    }
}
