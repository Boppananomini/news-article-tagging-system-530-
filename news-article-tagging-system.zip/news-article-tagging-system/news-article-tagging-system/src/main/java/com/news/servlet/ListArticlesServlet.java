package com.news.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.news.dao.HibernateUtil;
import com.news.model.NewsArticle;

@WebServlet("/ListArticlesServlet")
public class ListArticlesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<NewsArticle> articles = null;

        // ✅ Use try-with-resources to ensure session is closed automatically
        try (Session session = HibernateUtil.getFactory().openSession()) {
            Query<NewsArticle> query = session.createQuery("FROM NewsArticle", NewsArticle.class);
            articles = query.list();
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Unable to fetch articles.");
        }

        // ✅ Set articles in request scope (may be null if error occurred)
        request.setAttribute("articles", articles);

        // ✅ Forward to JSP
        request.getRequestDispatcher("list_articles.jsp").forward(request, response);
    }
}
