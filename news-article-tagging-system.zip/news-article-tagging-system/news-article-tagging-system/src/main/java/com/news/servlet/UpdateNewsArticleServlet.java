package com.news.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import com.news.dao.HibernateUtil;
import com.news.model.NewsArticle;

@WebServlet("/UpdateNewsArticleServlet")
public class UpdateNewsArticleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // ✅ Load the article and forward to update form
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int articleId = Integer.parseInt(request.getParameter("id"));

            Session session = HibernateUtil.getFactory().openSession();
            NewsArticle article = session.get(NewsArticle.class, articleId);
            session.close();

            if (article != null) {
                request.setAttribute("article", article);
                request.getRequestDispatcher("update_article.jsp").forward(request, response);
            } else {
                response.sendRedirect("ListArticlesServlet"); // if article not found
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ListArticlesServlet");
        }
    }

    // ✅ Handle form submission and update article
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String title = request.getParameter("title");
            String content = request.getParameter("content");

            Session session = HibernateUtil.getFactory().openSession();
            session.beginTransaction();

            NewsArticle article = session.get(NewsArticle.class, id);
            if (article != null) {
                article.setTitle(title);
                article.setContent(content);
                session.update(article);
            }

            session.getTransaction().commit();
            session.close();

            response.sendRedirect("ListArticlesServlet");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ListArticlesServlet");
        }
    }
}
