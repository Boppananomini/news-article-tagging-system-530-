package com.news.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.news.model.NewsArticle;

public class NewsArticleDAO {

    public void saveArticle(NewsArticle article) {
        Session session = HibernateUtil.getFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.persist(article);
        tx.commit();
        session.close();
    }

    public List<NewsArticle> getAllArticles() {
        Session session = HibernateUtil.getFactory().openSession();
        List<NewsArticle> list = session.createQuery("from NewsArticle", NewsArticle.class).list();
        session.close();
        return list;
    }
}
